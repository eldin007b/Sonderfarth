import React, { useEffect, useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  ActivityIndicator,
  TextInput,
  Alert,
  Pressable,
  Modal,
  Dimensions,
  Platform,
  SafeAreaView,
  RefreshControl,
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { LinearGradient } from 'expo-linear-gradient';
import * as Animatable from 'react-native-animatable';
import { MaterialCommunityIcons, MaterialIcons } from '@expo/vector-icons';
import BarcodeScannerModal from '../components/BarcodeScannerModal';
import { Audio } from 'expo-av';

const API_URL = 'https://dsltpiupbfopyvuiqffg.supabase.co/rest/v1/users';
const API_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRzbHRwaXVwYmZvcHl2dWlxZmZnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDk5Mjc3MzcsImV4cCI6MjA2NTUwMzczN30.suu_OSbTBSEkM3YMiPDFIAgDnX3bDavcD8BX4ZfYZxw';

const roles = [
  { label: 'User', value: 'user' },
  { label: 'Admin', value: 'admin' },
  { label: 'Moderator', value: 'moderator' },
];

export default function AdminPanel({ navigation }) {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [adding, setAdding] = useState(false);
  const [newUser, setNewUser] = useState({ user: '', pass: '', role: 'user' });
  const [scannerVisible, setScannerVisible] = useState(false);
  const [modalEdit, setModalEdit] = useState(false);
  const [modalDelete, setModalDelete] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [editUser, setEditUser] = useState({ user: '', pass: '', role: 'user', original: '' });
  const scrollRef = useRef();

  const brojAktivnih = users.filter(u => u.last_login && u.last_login.trim() !== '').length;

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${API_URL}?select=*`, {
        headers: {
          apikey: API_KEY,
          Authorization: `Bearer ${API_KEY}`,
        },
      });
      const data = await res.json();
      setUsers(data);
    } catch (err) {
      console.error('Fetch error:', err);
    }
    setLoading(false);
    setRefreshing(false);
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const playBeep = async () => {
    const { sound } = await Audio.Sound.createAsync(require('../assets/bip.mp3'));
    await sound.playAsync();
  };

  const handleBarcodeAdd = async ({ user, password }) => {
    if (!user || !password) return;
    await playBeep();
    setNewUser({ user: user.trim(), pass: password.trim(), role: 'user' });
    setScannerVisible(false);
  };

  const handleAddUser = async () => {
    if (!newUser.user || !newUser.pass) {
      Alert.alert('Greška', 'Popuni sva polja.');
      return;
    }
    setAdding(true);
    try {
      await fetch(API_URL, {
        method: 'POST',
        headers: {
          apikey: API_KEY,
          Authorization: `Bearer ${API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newUser),
      });
      fetchUsers();
      Alert.alert('OK', 'Korisnik uspješno dodan.');
    } catch (err) {
      Alert.alert('Greška', 'Greška pri dodavanju korisnika.');
    }
    setAdding(false);
    setNewUser({ user: '', pass: '', role: 'user' });
  };

  const handleDeleteUser = async () => {
    try {
      await fetch(`${API_URL}?user=eq.${selectedUser.user}`, {
        method: 'DELETE',
        headers: {
          apikey: API_KEY,
          Authorization: `Bearer ${API_KEY}`,
        },
      });
      Alert.alert('OK', `Korisnik ${selectedUser.user} obrisan.`);
      fetchUsers();
    } catch (err) {
      Alert.alert('Greška', 'Nemoguće obrisati korisnika.');
    }
    setModalDelete(false);
  };

  const handleEditUser = async () => {
    try {
      await fetch(`${API_URL}?user=eq.${editUser.original}`, {
        method: 'PATCH',
        headers: {
          apikey: API_KEY,
          Authorization: `Bearer ${API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          user: editUser.user,
          pass: editUser.pass,
          role: editUser.role,
        }),
      });
      Alert.alert('OK', `Korisnik ${editUser.user} ažuriran.`);
      fetchUsers();
    } catch (err) {
      Alert.alert('Greška', 'Nemoguće ažurirati korisnika.');
    }
    setModalEdit(false);
  };

  const openEditModal = item => {
    setEditUser({ ...item, original: item.user });
    setModalEdit(true);
  };

  const openDeleteModal = item => {
    setSelectedUser(item);
    setModalDelete(true);
  };

  const safeGoBack = () => {
    if (navigation.canGoBack()) navigation.goBack();
    else navigation.replace('MainMenu');
  };

  const UserCard = ({ item }) => (
    <Animatable.View animation="fadeInUp" style={styles.userCard}>
      <View>
        <Text style={styles.userName}>{item.user}</Text>
        <Text style={styles.userRole}>{item.role}</Text>
      </View>
      <View style={styles.actionIcons}>
        <Pressable onPress={() => openEditModal(item)} style={styles.iconWrap}>
          <MaterialCommunityIcons name="pencil" size={22} color="#388E3C" />
        </Pressable>
        <Pressable onPress={() => openDeleteModal(item)} style={styles.iconWrap}>
          <MaterialCommunityIcons name="trash-can" size={22} color="#D32F2F" />
        </Pressable>
      </View>
    </Animatable.View>
  );

  return (
    <View style={styles.flex}>
      <LinearGradient colors={['#1976D2', '#42a5f5']} style={styles.container}>
        <SafeAreaView style={styles.flex}>
          <View style={styles.header}>
            <Pressable onPress={safeGoBack} style={styles.navBtn}>
              <MaterialCommunityIcons name="arrow-left" size={28} color="#fff" />
            </Pressable>
            <Animatable.Text animation="fadeInDown" style={styles.title}>
              Admin Panel
            </Animatable.Text>
            <Pressable onPress={() => navigation.replace('MainMenu')} style={styles.navBtn}>
              <MaterialIcons name="home" size={28} color="#fff" />
            </Pressable>
          </View>

          <View style={styles.statsRow}>
            <Text style={styles.statsText}>Ukupno: {users.length}</Text>
            <Text style={styles.statsText}>Aktivni: {brojAktivnih}</Text>
          </View>

          <View style={styles.controlsContainer}>
            <Pressable onPress={() => setScannerVisible(true)} style={styles.scanBtn}>
              <Text style={styles.scanText}>Skeniraj Barcode</Text>
            </Pressable>
            <BarcodeScannerModal
              visible={scannerVisible}
              onScan={handleBarcodeAdd}
              onClose={() => setScannerVisible(false)}
            />
            <TextInput
              placeholder="Korisničko ime"
              value={newUser.user}
              onChangeText={t => setNewUser(p => ({ ...p, user: t }))}
              style={styles.input}
              autoCapitalize="none"
            />
            <TextInput
              placeholder="Lozinka"
              value={newUser.pass}
              onChangeText={t => setNewUser(p => ({ ...p, pass: t }))}
              style={styles.input}
            />
            <View style={styles.pickerWrap}>
              <Picker
                selectedValue={newUser.role}
                onValueChange={r => setNewUser(p => ({ ...p, role: r }))}
                style={styles.picker}
              >
                {roles.map(r => (
                  <Picker.Item key={r.value} label={r.label} value={r.value} />
                ))}
              </Picker>
            </View>
            <Pressable onPress={handleAddUser} style={styles.addBtn}>
              <Text style={styles.addText}>{adding ? 'Dodajem...' : 'Dodaj korisnika'}</Text>
            </Pressable>
          </View>

          <FlatList
            ref={scrollRef}
            data={users}
            keyExtractor={(i, idx) => `${i.user}_${idx}`}
            renderItem={({ item }) => <UserCard item={item} />}
            refreshControl={
              <RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchUsers(); }} />
            }
            contentContainerStyle={{ paddingBottom: 80 }}
          />
        </SafeAreaView>
      </LinearGradient>
    </View>
  );
}

const { width } = Dimensions.get('window');
const styles = StyleSheet.create({
  flex: { flex: 1 },
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: Platform.OS === 'android' ? 40 : 60,
  },
  navBtn: { padding: 8 },
  title: { fontSize: 24, fontWeight: 'bold', color: '#fff' },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    marginTop: 10,
  },
  statsText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  controlsContainer: {
    padding: 20,
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  scanBtn: {
    backgroundColor: '#fff',
    padding: 14,
    borderRadius: 12,
    marginBottom: 12,
    alignItems: 'center',
  },
  scanText: { color: '#1976D2', textAlign: 'center', fontWeight: 'bold' },
  input: {
    backgroundColor: '#fff',
    padding: 14,
    borderRadius: 10,
    marginBottom: 12,
    fontSize: 16,
  },
  pickerWrap: { backgroundColor: '#fff', borderRadius: 10, marginBottom: 14 },
  picker: { height: 50 },
  addBtn: {
    backgroundColor: '#1976D2',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 10,
  },
  addText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  userCard: {
    backgroundColor: '#fff',
    marginHorizontal: 20,
    marginBottom: 12,
    borderRadius: 14,
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    elevation: 3,
  },
  userName: { fontSize: 17, fontWeight: 'bold', color: '#222' },
  userRole: { fontSize: 14, color: '#1976D2' },
  actionIcons: { flexDirection: 'row' },
  iconWrap: { marginLeft: 10 },
  empty: { textAlign: 'center', marginTop: 30, fontSize: 16, color: '#fff' },
  fab: {
    position: 'absolute',
    bottom: 24,
    right: 24,
    backgroundColor: '#1976D2',
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 6,
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.15)',
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: 24,
    borderRadius: 16,
    width: width * 0.85,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 12,
    color: '#1976D2',
    textAlign: 'center',
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 12,
  },
  iconBtn: { padding: 8 },
});
